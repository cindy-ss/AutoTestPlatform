// Meta data used by the AngularJS docs app
angular.module('navData', [])
  .value('NG_NAVIGATION', {$ doc.areas | json $});
